package com.example.online_education_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
